[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$pluginName = 'Studio Reverb.vst3'
$source = Join-Path $PSScriptRoot $pluginName
$destination = Join-Path $env:CommonProgramFiles 'VST3'

if (-not (Test-Path -LiteralPath $source)) {
    throw "Cannot find $pluginName next to this installer. Extract the entire ZIP first, then run this file again."
}

$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $arguments = "-NoProfile -ExecutionPolicy Bypass -File `"$PSCommandPath`""
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList $arguments
    exit
}

New-Item -ItemType Directory -Path $destination -Force | Out-Null
Copy-Item -LiteralPath $source -Destination (Join-Path $destination $pluginName) -Recurse -Force
Write-Host "Studio Reverb installed to: $destination" -ForegroundColor Green
Write-Host 'Restart your DAW and rescan plugins if it does not appear immediately.'
Read-Host 'Press Enter to close'
